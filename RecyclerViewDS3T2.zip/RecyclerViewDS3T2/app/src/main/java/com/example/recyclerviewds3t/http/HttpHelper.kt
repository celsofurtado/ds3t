package com.example.recyclerviewds3t.http

import okhttp3.MediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.Request

class HttpHelper {

    private fun enviarImagem(json: String) : String {

        // determinar a URL do endpoint no servidor
        val URL = "http://192.168.15.12:8080/odonto/upload"

        // definir o cabeçalho da requisição
        val headerHttp = MediaType.parse("application/json; charset=utf-8")

        // Criar um cliente Http
        var client = OkHttpClient()

        // Body da requisição
        val body = RequestBody.create(headerHttp, json)

        // Construir a requisição http para o servidor
        var request = Request.Builder().url(URL).post(body).build()

        // Criar a resposta do servidor
        var response = client.newCall(request).execute()

        // retorna a resposta do servidor para o cliente
        return response.body().toString()

    }
}