package com.example.recyclerviewds3t

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_cadastro_foto.*

class CadastroFotoActivity : AppCompatActivity(), View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro_foto)

        faFoto.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        val id = view.id

        if (id == R.id.faFoto){
            abrirGaleriaDeFotos()
        }

    }

    private fun abrirGaleriaDeFotos() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "image/*"
        startActivityForResult(Intent.createChooser(intent, "Selecionar Imagem"), 4587)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        if (resultCode == -1 && data != null){
            val input = contentResolver.openInputStream(data.data!!)
            var bitmap = BitmapFactory.decodeStream(input)
            imageFoto.setImageBitmap(bitmap)
        }

        super.onActivityResult(requestCode, resultCode, data)
    }
}
