package com.example.recyclerviewds3t

import com.example.recyclerviewds3t.model.Dentista

class DataSource {

    companion object {
        fun createDataset() : ArrayList<Dentista>{

            var lista = ArrayList<Dentista>()

            lista.add(Dentista(1, "Pedro da Silva", "11111", "pedro@terra.com.br", "(11)1245-8956"))
            lista.add(Dentista(2, "Ana da Silva", "11111", "pedro@terra.com.br", "(11)1245-8956"))
            lista.add(Dentista(3, "Fabiana da Silva", "11111", "pedro@terra.com.br", "(11)1245-8956"))
            lista.add(Dentista(4, "Patricia da Silva", "11111", "pedro@terra.com.br", "(11)1245-8956"))
            lista.add(Dentista(5, "Francisco da Silva", "11111", "pedro@terra.com.br", "(11)1245-8956"))
            lista.add(Dentista(6, "Bruna da Silva", "11111", "pedro@terra.com.br", "(11)1245-8956"))
            lista.add(Dentista(1, "Pedro da Silva", "11111", "pedro@terra.com.br", "(11)1245-8956"))
            lista.add(Dentista(2, "Ana da Silva", "11111", "pedro@terra.com.br", "(11)1245-8956"))
            lista.add(Dentista(3, "Fabiana da Silva", "11111", "pedro@terra.com.br", "(11)1245-8956"))
            lista.add(Dentista(4, "Patricia da Silva", "11111", "pedro@terra.com.br", "(11)1245-8956"))
            lista.add(Dentista(5, "Francisco da Silva", "11111", "pedro@terra.com.br", "(11)1245-8956"))
            lista.add(Dentista(6, "Bruna da Silva", "11111", "pedro@terra.com.br", "(11)1245-8956"))

            return lista
        }
    }


}