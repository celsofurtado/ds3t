package com.example.recyclerviewds3t.model

data class Dentista (
    var codigo: Int,
    var nome: String,
    var cro: String,
    var email: String,
    var telefone: String
) {
}