package com.example.recyclerviewds3t

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AbsListView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerviewds3t.adapter.DentistaRecyclerAdapter
import kotlinx.android.synthetic.main.activity_cadastro_foto.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), View.OnClickListener {

    lateinit var dentistaRecyclerAdapter: DentistaRecyclerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inicializarRecyclerView()

        faCadastro.setOnClickListener(this)

    }

    override fun onClick(view: View) {

        val id = view.id

        if (id == R.id.faCadastro){
            var intent = Intent(this, CadastroFotoActivity::class.java)
            startActivity(intent)
        }

    }

    private fun inicializarRecyclerView(){
        
        rvDentistas.layoutManager = LinearLayoutManager(this)
        dentistaRecyclerAdapter = DentistaRecyclerAdapter(DataSource.createDataset())
        rvDentistas.adapter = dentistaRecyclerAdapter

    }
}
