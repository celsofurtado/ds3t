package br.senai.sp.jandira.odonto.model;

import java.util.stream.Stream;

public class Imc {
	
	private double valor;
	private String classificacao;
	private String dica;
	private String nivelRisco;
	private Stream<?> imagem;
	
	

}
